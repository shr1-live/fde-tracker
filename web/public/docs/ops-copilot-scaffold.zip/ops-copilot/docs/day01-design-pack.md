# Day 1 design pack: IoT OpsCopilot

## 1. Problem statement (half a page)
- Who has the problem and what they do today:
- What goes wrong today and what it costs:
- What the OpsCopilot will do (3 verbs) and will not do:
- How we will know it works (3 measurable outcomes):
- Assumptions to confirm with the customer:

## 2. Ten discovery questions (edit, then answer each as the customer; mark guesses)
1. Who looks at alerts first, and how many do they handle per shift?
2. What does a good response to an alert look like, step by step?
3. Where do the runbooks live today, and who keeps them current?
4. Which actions may the assistant take on its own, and which must a person approve?
5. What data may it read, and what must it never touch?
6. How fast must an answer be, and what wrong-answer rate is acceptable?
7. Which systems must it connect to (ticketing, device database)?
8. What happens if the assistant is wrong or unavailable?
9. Who approves risky actions, and what evidence do they need on screen?
10. How will you measure success after one month?

## 3. Architecture sketch
(client, API, LLM wrapper, vector store, tools, database, MCP server, approval step; add a drawing or ASCII diagram)

## 4. API list
- POST /triage
- POST /ask
- POST /agent/run

## 5. Data model
| Table | Columns |
|---|---|
| Devices | DeviceId, Type, Site, InstalledOn |
| Readings | DeviceId, Timestamp, Temperature, Vibration, Battery |
| Alerts | AlertId, DeviceId, RaisedAt, Severity, Status |
| Tickets | TicketId, AlertId, CreatedAt, CreatedBy, Summary |
| AuditLog | Id, Timestamp, Step, Tool, Arguments, Result, Approver |

## 6. Threats and mitigations
1. Prompt injection inside a runbook or alert text:
2. The agent takes a write action nobody approved:
3. A secret or key leaks into code, logs or a prompt:
4. Personal or sensitive data in logs or prompts:
5. Cost abuse (loops, huge inputs):
