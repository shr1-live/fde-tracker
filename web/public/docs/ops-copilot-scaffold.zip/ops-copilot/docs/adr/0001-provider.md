# ADR 0001: Provider and model

Status: accepted
Context: what forced a choice (Azure access, hardware, cost)
Options: A) Azure OpenAI  B) Ollama local  C) hosted API key
Decision:
Consequences: what gets easier, what gets harder, how we reverse it
