# Day 1 teach-back (5 lines)
1. What I built today:
2. Why it is needed:
3. What failed and how I fixed it:
4. What I would explain to a colleague in one minute:
5. What I am unsure about:
