# ops-copilot

IoT OpsCopilot: RAG over runbooks, tools over device telemetry, an agent that needs approval before acting, served over MCP.
Built one layer a day over 10 days as part of the FDE training.

Track: A (Azure) or B (local)  <- write your choice here on Day 1

## Layers
L0 design + foundation, L1 prompts + structured output, L2 tools, L3 embeddings + ingest, L4 RAG,
L5 agent + approval, L6 MCP, L7 evaluation + guardrails + CI, L8 AI-assisted delivery + deploy + monitor.
