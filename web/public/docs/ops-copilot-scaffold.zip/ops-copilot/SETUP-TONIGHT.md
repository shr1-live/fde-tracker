# Setup tonight (about 45 minutes)

Tick each box. If one fails, copy the exact error into the "Problems" section at the bottom and bring it back to the chat.

## 1. Ollama and models (local track, and your safety net)
- [ ] Install Ollama from https://ollama.com
- [ ] Terminal: `ollama pull phi3`
- [ ] Terminal: `ollama pull nomic-embed-text`
- [ ] Check: `ollama list` shows both
- [ ] Check: `ollama run phi3` then type a question, then `/bye`
If phi3 is too slow or fails, try `ollama pull llama3.2`.

## 2. .NET SDK
- [ ] Install the .NET SDK from https://dotnet.microsoft.com/download (the MCP tutorial uses .NET 10; check each quickstart's required version)
- [ ] Check: `dotnet --version`

## 3. Git and repo
- [ ] Create a private GitHub repo named ops-copilot
- [ ] Unzip this scaffold into your clone, or: `git clone <your-url>`, copy these files in
- [ ] `git add . && git commit -m "Scaffold" && git push`
- [ ] Check: `git status` is clean

## 4. Azure (do not wait for it)
- [ ] Ask for or check access to: Azure OpenAI resource with one chat deployment, one embedding deployment, and a Key Vault
- [ ] Write down: endpoint URL, chat deployment name, embedding deployment name, who to ask
If you do not have it by 9 am tomorrow: you are on Track B. Write that in notes/tracker.md.

## 5. Docker (optional tonight, needed Day 9)
- [ ] Install Docker Desktop; check `docker --version`

## 6. Tracker
- [ ] Open notes/tracker.md and fill the "Track chosen" line tomorrow morning

## Problems (paste errors here)
