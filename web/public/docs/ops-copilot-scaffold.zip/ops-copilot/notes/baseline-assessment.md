# Baseline self-assessment (rate 1 to 5; repeat on Day 10)

| Outline skill | Target | Day 1 | Day 10 |
|---|---|---|---|
| LLM integration and prompting | Build independently | | |
| RAG and vector databases | Build independently | | |
| AI agents and tool calling | Build independently | | |
| MCP integrations | Build independently | | |
| AI application architecture | Design independently | | |
| AI evaluation and guardrails | Implement independently | | |
| Fine-tuning existing models | Understand and experiment | | |
| Training models from scratch | Conceptual understanding | | |
| Agentic coding tools | Use effectively in daily development | | |
| Production deployment and monitoring | Implement independently | | |
