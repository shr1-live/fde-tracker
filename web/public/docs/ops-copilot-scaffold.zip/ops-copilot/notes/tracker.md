# Tracker

Track chosen (A Azure / B local): ______   Decided on: ______

| Day | Layer | Planned | Done | Hours | Blockers | Confidence 1-5 |
|---|---|---|---|---|---|---|
| 1 | L0 design + foundation |  |  |  |  |  |
| 2 | L1 prompts + structured output |  |  |  |  |  |
| 3 | L2 tools |  |  |  |  |  |
| 4 | L3 embeddings + ingest |  |  |  |  |  |
| 5 | L4 RAG + citations |  |  |  |  |  |
| 6 | L5 agent + approval |  |  |  |  |  |
| 7 | L6 MCP |  |  |  |  |  |
| 8 | L7 eval + guardrails + CI |  |  |  |  |  |
| 9 | L8 AI-assisted delivery + deploy |  |  |  |  |  |
| 10 | Wrap-up + fine-tuning experiment |  |  |  |  |  |
